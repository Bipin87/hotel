package com.hotel.bookingService.model;

public enum BookingStatus {
    PENDING,
    BOOKED,
    CANCELLED,
}
