package com.hms.ratingservice.service;

import com.hms.ratingservice.entities.Rating;

import java.util.List;

public interface RatingService {

    public Rating addRating(Rating rating);

    public List<Rating> getRatingAll();

    public List<Rating> getRatingByUserId(String userId);

    public List<Rating> getRatingByHotelId(String hotelId);

}
