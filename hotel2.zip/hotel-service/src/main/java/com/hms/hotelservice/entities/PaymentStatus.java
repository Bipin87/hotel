package com.hms.hotelservice.entities;

public enum PaymentStatus {
    PAID, UNPAID
}
