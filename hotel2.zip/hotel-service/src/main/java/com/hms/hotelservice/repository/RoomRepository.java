package com.hms.hotelservice.repository;

import com.hms.hotelservice.entities.Room;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoomRepository extends JpaRepository<Room, String> {
}
