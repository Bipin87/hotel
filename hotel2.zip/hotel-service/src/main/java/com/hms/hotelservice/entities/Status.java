package com.hms.hotelservice.entities;

public enum Status {
    AVAILABLE, BOOKED
}
