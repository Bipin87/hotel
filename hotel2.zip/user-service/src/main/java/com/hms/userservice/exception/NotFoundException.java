package com.hms.userservice.exception;

public class NotFoundException extends RuntimeException{
	
	public NotFoundException(String str){
		super(str) ;
	}

}
