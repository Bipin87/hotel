package com.hms.userservice.exception;

public class HotelException extends RuntimeException{

            public HotelException(String str){
                super(str) ;
            }
            public HotelException(){

            }
}
