package com.hms.userservice.exception;

public class UserException extends RuntimeException{

        public UserException(String str){
            super(str) ;
        }
        public UserException(){

        }
}
