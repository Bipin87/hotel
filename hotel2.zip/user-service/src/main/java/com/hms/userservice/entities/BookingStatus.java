package com.hms.userservice.entities;

public enum BookingStatus {
    CANCELLED,
    BOOKED,
    COMPLETED,

}
