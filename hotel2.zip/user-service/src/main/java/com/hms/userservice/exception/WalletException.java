package com.hms.userservice.exception;

public class WalletException extends RuntimeException{

    public WalletException(String str){
        super(str) ;
    }

    public WalletException(){

    }
}
