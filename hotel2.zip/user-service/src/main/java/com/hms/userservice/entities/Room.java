package com.hms.userservice.entities;

import lombok.Data;

@Data
public class Room {
    private String roomId;
    private String roomType;
    private String roomNumber;
    private Integer roomPrice;
    private Status Status;
    private String roomDescription;
    private Hotel hotel;
}
