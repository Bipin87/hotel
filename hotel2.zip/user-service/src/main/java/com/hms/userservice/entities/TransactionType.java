package com.hms.userservice.entities;

public enum TransactionType {
    DEBIT, CREDIT
}
