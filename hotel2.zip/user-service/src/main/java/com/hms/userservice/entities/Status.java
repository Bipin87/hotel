package com.hms.userservice.entities;

public enum Status {
    AVAILABLE, BOOKED
}
