package com.hms.userservice.entities;

public enum PaymentStatus {
    PAID, UNPAID
}
