package com.hms.userservice.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

import java.util.List;

@Data
public class Hotel {

    private String id;
    private String name;
    private String location;
    private String about;
    private List<Room> rooms;
    @JsonIgnore
    private List<Booking> bookings;

}
