package com.hotel.reservation_service.controller;

import com.hotel.reservation_service.dto.ReservationDTO;
import com.hotel.reservation_service.entity.Reservation;
import com.hotel.reservation_service.service_layer.ReservationService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/reservations")
@RequiredArgsConstructor
public class ReservationController {

    private final ReservationService service;

    @PostMapping
    public Reservation create(@RequestBody @Valid ReservationDTO dto) {
        return service.createReservation(dto);
    }

    @GetMapping("/{id}")
    public Reservation getById(@PathVariable Long id) {
        return service.getReservationById(id);
    }

    @GetMapping
    public List<Reservation> getAll() {
        return service.getAllReservations();
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        service.deleteReservation(id);
    }
}
