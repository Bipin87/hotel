package com.hotel.reservation_service.dto;

import lombok.*;
import jakarta.validation.constraints.*;
import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ReservationDTO {

    @NotNull
    private Long guestId;

    @NotNull
    private Long roomId;

    @FutureOrPresent
    private LocalDate checkInDate;

    @Future
    private LocalDate checkOutDate;

    @Min(1)
    private int numOfAdults;

    @Min(0)
    private int numOfChildren;
}
