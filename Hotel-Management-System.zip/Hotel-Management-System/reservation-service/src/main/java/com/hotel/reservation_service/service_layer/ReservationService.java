package com.hotel.reservation_service.service_layer;

import com.hotel.reservation_service.dto.ReservationDTO;
import com.hotel.reservation_service.entity.Reservation;

import java.util.List;

public interface ReservationService {
    Reservation createReservation(ReservationDTO dto);
    Reservation getReservationById(Long id);
    List<Reservation> getAllReservations();
    void deleteReservation(Long id);
}
