package com.hotel.reservation_service.service_layer;

import com.hotel.reservation_service.dto.ReservationDTO;
import com.hotel.reservation_service.entity.Reservation;
import com.hotel.reservation_service.exception.ResourceNotFoundException;
import com.hotel.reservation_service.repository.ReservationRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class ReservationServiceImpl implements ReservationService {

    private final ReservationRepository repository;

    @Override
    public Reservation createReservation(ReservationDTO dto) {
        Reservation reservation = Reservation.builder()
                .guestId(dto.getGuestId())
                .roomId(dto.getRoomId())
                .checkInDate(dto.getCheckInDate())
                .checkOutDate(dto.getCheckOutDate())
                .numOfAdults(dto.getNumOfAdults())
                .numOfChildren(dto.getNumOfChildren())
                .status("BOOKED")
                .build();

        log.info("Creating reservation for guest ID {}", dto.getGuestId());
        return repository.save(reservation);
    }

    @Override
    public Reservation getReservationById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Reservation not found with ID: " + id));
    }

    @Override
    public List<Reservation> getAllReservations() {
        return repository.findAll();
    }

    @Override
    public void deleteReservation(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("Cannot delete. Reservation not found with ID: " + id);
        }
        repository.deleteById(id);
        log.info("Deleted reservation ID {}", id);
    }
}
