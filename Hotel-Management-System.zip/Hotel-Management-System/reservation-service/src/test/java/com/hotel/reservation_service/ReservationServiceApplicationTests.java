package com.hotel.reservation_service;

import com.hotel.reservation_service.dto.ReservationDTO;
import com.hotel.reservation_service.entity.Reservation;
import com.hotel.reservation_service.repository.ReservationRepository;
import com.hotel.reservation_service.service_layer.ReservationServiceImpl;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@SpringBootTest
class ReservationServiceApplicationTests {

	@Mock
	ReservationRepository repository;

	@InjectMocks
	ReservationServiceImpl service;

	public ReservationServiceApplicationTests() {
		MockitoAnnotations.openMocks(this);
	}
	@Test
	void contextLoads() {
		ReservationDTO dto = ReservationDTO.builder()
				.guestId(1L)
				.roomId(101L)
				.checkInDate(LocalDate.now())
				.checkOutDate(LocalDate.now().plusDays(2))
				.numOfAdults(2)
				.numOfChildren(1)
				.build();

		when(repository.save(any())).thenAnswer(i -> i.getArgument(0));

		Reservation saved = service.createReservation(dto);
		assertEquals(2, saved.getNumOfAdults());
	}

}
