package com.hotel.room_service.dto;

import jakarta.validation.constraints.*;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RoomDTO {

    @NotBlank
    private String roomNumber;

    @NotBlank
    private String type;

    @Min(1)
    private int capacity;

    @Min(0)
    private double price;

    private boolean isAvailable;
}
