package com.hotel.room_service.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Room {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    private String roomNumber;

    @NotBlank
    private String type;

    @Min(1)
    private int capacity;

    @Min(0)
    private double price;

    private boolean isAvailable;
}
