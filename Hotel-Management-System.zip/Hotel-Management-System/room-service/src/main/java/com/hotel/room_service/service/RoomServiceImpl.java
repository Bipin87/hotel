package com.hotel.room_service.service;

import com.hotel.room_service.dto.RoomDTO;
import com.hotel.room_service.entity.Room;
import com.hotel.room_service.exception.RoomNotFoundException;
import com.hotel.room_service.repository.RoomRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class RoomServiceImpl implements RoomService {

    private final RoomRepository repository;

    @Override
    public Room createRoom(RoomDTO dto) {
        Room room = Room.builder()
                .roomNumber(dto.getRoomNumber())
                .type(dto.getType())
                .capacity(dto.getCapacity())
                .price(dto.getPrice())
                .isAvailable(dto.isAvailable())
                .build();
        return repository.save(room);
    }

    @Override
    public Room getRoom(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RoomNotFoundException("Room not found with ID: " + id));
    }

    @Override
    public List<Room> getAllRooms() {
        return repository.findAll();
    }

    @Override
    public Room updateRoom(Long id, RoomDTO dto) {
        Room room = getRoom(id);
        room.setRoomNumber(dto.getRoomNumber());
        room.setType(dto.getType());
        room.setCapacity(dto.getCapacity());
        room.setPrice(dto.getPrice());
        room.setAvailable(dto.isAvailable());
        return repository.save(room);
    }

    @Override
    public void deleteRoom(Long id) {
        if (!repository.existsById(id)) {
            throw new RoomNotFoundException("Room not found with ID: " + id);
        }
        repository.deleteById(id);
    }
}
