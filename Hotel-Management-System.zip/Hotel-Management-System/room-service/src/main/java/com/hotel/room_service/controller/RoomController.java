package com.hotel.room_service.controller;

import com.hotel.room_service.dto.RoomDTO;
import com.hotel.room_service.entity.Room;
import com.hotel.room_service.service.RoomService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/rooms")
@RequiredArgsConstructor
public class RoomController {

    private final RoomService service;

    @PostMapping
    public Room create(@RequestBody @Valid RoomDTO dto) {
        return service.createRoom(dto);
    }

    @GetMapping("/{id}")
    public Room getById(@PathVariable Long id) {
        return service.getRoom(id);
    }

    @GetMapping
    public List<Room> getAll() {
        return service.getAllRooms();
    }

    @PutMapping("/{id}")
    public Room update(@PathVariable Long id, @RequestBody @Valid RoomDTO dto) {
        return service.updateRoom(id, dto);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        service.deleteRoom(id);
    }
}
