package com.hotel.room_service.service;

import com.hotel.room_service.dto.RoomDTO;
import com.hotel.room_service.entity.Room;

import java.util.List;

public interface RoomService {
    Room createRoom(RoomDTO dto);
    Room getRoom(Long id);
    List<Room> getAllRooms();
    Room updateRoom(Long id, RoomDTO dto);
    void deleteRoom(Long id);
}
