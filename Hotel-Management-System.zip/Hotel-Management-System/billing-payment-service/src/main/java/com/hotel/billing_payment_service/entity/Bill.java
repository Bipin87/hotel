package com.hotel.billing_payment_service.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

import java.time.LocalDate;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Bill {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long reservationId;

    @NotNull
    private LocalDate billingDate;

    @Min(0)
    private double amount;

    @NotBlank
    private String paymentMode; // e.g., "CREDIT_CARD", "CASH"

    @NotBlank
    private String status; // e.g., "PAID", "PENDING"
}
