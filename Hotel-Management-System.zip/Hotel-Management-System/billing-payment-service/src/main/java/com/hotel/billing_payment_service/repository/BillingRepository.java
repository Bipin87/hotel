package com.hotel.billing_payment_service.repository;

import com.hotel.billing_payment_service.entity.Bill;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BillingRepository extends JpaRepository<Bill, Long> {
}
