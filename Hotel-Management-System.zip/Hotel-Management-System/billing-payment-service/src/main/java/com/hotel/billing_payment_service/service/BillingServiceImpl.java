package com.hotel.billing_payment_service.service;

import com.hotel.billing_payment_service.dto.BillDTO;
import com.hotel.billing_payment_service.entity.Bill;
import com.hotel.billing_payment_service.exception.BillNotFoundException;
import com.hotel.billing_payment_service.repository.BillingRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class BillingServiceImpl implements BillingService {

    private final BillingRepository repository;

    @Override
    public Bill generateBill(BillDTO dto) {
        Bill bill = Bill.builder()
                .reservationId(dto.getReservationId())
                .billingDate(dto.getBillingDate())
                .amount(dto.getAmount())
                .paymentMode(dto.getPaymentMode())
                .status(dto.getStatus())
                .build();
        return repository.save(bill);
    }

    @Override
    public Bill getBill(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new BillNotFoundException("Bill not found with ID: " + id));
    }

    @Override
    public List<Bill> getAllBills() {
        return repository.findAll();
    }

    @Override
    public void deleteBill(Long id) {
        if (!repository.existsById(id)) {
            throw new BillNotFoundException("Cannot delete. Bill not found with ID: " + id);
        }
        repository.deleteById(id);
    }
}
