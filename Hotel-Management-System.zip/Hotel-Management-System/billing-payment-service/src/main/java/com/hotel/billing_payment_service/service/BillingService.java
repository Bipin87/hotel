package com.hotel.billing_payment_service.service;

import com.hotel.billing_payment_service.dto.BillDTO;
import com.hotel.billing_payment_service.entity.Bill;

import java.util.List;

public interface BillingService {
    Bill generateBill(BillDTO dto);
    Bill getBill(Long id);
    List<Bill> getAllBills();
    void deleteBill(Long id);
}
