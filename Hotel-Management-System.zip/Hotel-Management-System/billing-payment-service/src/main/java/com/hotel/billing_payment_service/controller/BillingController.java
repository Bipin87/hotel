package com.hotel.billing_payment_service.controller;

import com.hotel.billing_payment_service.dto.BillDTO;
import com.hotel.billing_payment_service.entity.Bill;
import com.hotel.billing_payment_service.service.BillingService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/billing")
@RequiredArgsConstructor
public class BillingController {

    private final BillingService billingService;

    @PostMapping
    public Bill createBill(@RequestBody @Valid BillDTO dto) {
        return billingService.generateBill(dto);
    }

    @GetMapping("/{id}")
    public Bill getBillById(@PathVariable Long id) {
        return billingService.getBill(id);
    }

    @GetMapping
    public List<Bill> getAll() {
        return billingService.getAllBills();
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        billingService.deleteBill(id);
    }
}
