package com.hotel.billing_payment_service.dto;

import jakarta.validation.constraints.*;
import lombok.*;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BillDTO {

    private Long reservationId;

    private LocalDate billingDate;

    @Min(0)
    private double amount;

    private String paymentMode;

    private String status;
}
