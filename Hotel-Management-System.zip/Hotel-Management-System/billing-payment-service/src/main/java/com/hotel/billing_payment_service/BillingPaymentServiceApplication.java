package com.hotel.billing_payment_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BillingPaymentServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BillingPaymentServiceApplication.class, args);
	}

}
