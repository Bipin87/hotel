package com.hotel.rate_service.service;

import com.hotel.rate_service.dto.RateDTO;
import com.hotel.rate_service.entity.Rate;

import java.util.List;

public interface RateService {
    Rate createRate(RateDTO dto);
    Rate getRate(Long id);
    List<Rate> getAllRates();
    Rate updateRate(Long id, RateDTO dto);
    void deleteRate(Long id);
}
