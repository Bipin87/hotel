package com.hotel.rate_service.controller;

import com.hotel.rate_service.dto.RateDTO;
import com.hotel.rate_service.entity.Rate;
import com.hotel.rate_service.service.RateService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/rates")
@RequiredArgsConstructor
public class RateController {

    private final RateService service;

    @PostMapping
    public Rate create(@RequestBody @Valid RateDTO dto) {
        return service.createRate(dto);
    }

    @GetMapping("/{id}")
    public Rate get(@PathVariable Long id) {
        return service.getRate(id);
    }

    @GetMapping
    public List<Rate> getAll() {
        return service.getAllRates();
    }

    @PutMapping("/{id}")
    public Rate update(@PathVariable Long id, @RequestBody @Valid RateDTO dto) {
        return service.updateRate(id, dto);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        service.deleteRate(id);
    }
}
