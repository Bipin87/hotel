package com.hotel.rate_service.repository;

import com.hotel.rate_service.entity.Rate;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RateRepository extends JpaRepository<Rate, Long> {
}
