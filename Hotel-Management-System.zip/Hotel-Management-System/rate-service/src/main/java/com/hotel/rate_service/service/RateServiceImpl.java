package com.hotel.rate_service.service;

import com.hotel.rate_service.dto.RateDTO;
import com.hotel.rate_service.entity.Rate;
import com.hotel.rate_service.exception.RateNotFoundException;
import com.hotel.rate_service.repository.RateRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class RateServiceImpl implements RateService {

    private final RateRepository repository;

    @Override
    public Rate createRate(RateDTO dto) {
        Rate rate = Rate.builder()
                .roomType(dto.getRoomType())
                .effectiveFrom(dto.getEffectiveFrom())
                .effectiveTo(dto.getEffectiveTo())
                .baseRate(dto.getBaseRate())
                .weekendRate(dto.getWeekendRate())
                .build();
        return repository.save(rate);
    }

    @Override
    public Rate getRate(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RateNotFoundException("Rate not found with ID: " + id));
    }

    @Override
    public List<Rate> getAllRates() {
        return repository.findAll();
    }

    @Override
    public Rate updateRate(Long id, RateDTO dto) {
        Rate rate = getRate(id);
        rate.setRoomType(dto.getRoomType());
        rate.setEffectiveFrom(dto.getEffectiveFrom());
        rate.setEffectiveTo(dto.getEffectiveTo());
        rate.setBaseRate(dto.getBaseRate());
        rate.setWeekendRate(dto.getWeekendRate());
        return repository.save(rate);
    }

    @Override
    public void deleteRate(Long id) {
        if (!repository.existsById(id)) {
            throw new RateNotFoundException("Rate not found with ID: " + id);
        }
        repository.deleteById(id);
    }
}
