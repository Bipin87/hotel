package com.hotel.rate_service.dto;

import jakarta.validation.constraints.*;
import lombok.*;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RateDTO {

    @NotBlank
    private String roomType;

    @NotNull
    private LocalDate effectiveFrom;

    @NotNull
    private LocalDate effectiveTo;

    @Min(0)
    private double baseRate;

    @Min(0)
    private double weekendRate;
}
