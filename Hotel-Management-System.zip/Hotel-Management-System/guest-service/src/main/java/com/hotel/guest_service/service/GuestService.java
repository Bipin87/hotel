package com.hotel.guest_service.service;

import com.hotel.guest_service.dto.GuestDTO;
import com.hotel.guest_service.entity.Guest;

import java.util.List;

public interface GuestService {
    Guest createGuest(GuestDTO dto);
    Guest getGuest(Long id);
    List<Guest> getAllGuests();
    Guest updateGuest(Long id, GuestDTO dto);
    void deleteGuest(Long id);
}
