package com.hotel.guest_service.dto;

import jakarta.validation.constraints.*;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class GuestDTO {

    @NotBlank
    private String name;

    @Email
    private String email;

    @NotBlank
    private String phone;

    private String gender;

    @NotBlank
    private String address;
}
