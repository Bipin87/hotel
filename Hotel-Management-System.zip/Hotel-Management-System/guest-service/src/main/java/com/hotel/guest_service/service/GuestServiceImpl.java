package com.hotel.guest_service.service;

import com.hotel.guest_service.dto.GuestDTO;
import com.hotel.guest_service.entity.Guest;
import com.hotel.guest_service.exception.GuestNotFoundException;
import com.hotel.guest_service.repository.GuestRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class GuestServiceImpl implements GuestService {

    private final GuestRepository repository;

    @Override
    public Guest createGuest(GuestDTO dto) {
        Guest guest = Guest.builder()
                .name(dto.getName())
                .email(dto.getEmail())
                .phone(dto.getPhone())
                .gender(dto.getGender())
                .address(dto.getAddress())
                .build();
        return repository.save(guest);
    }

    @Override
    public Guest getGuest(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new GuestNotFoundException("Guest not found with ID: " + id));
    }

    @Override
    public List<Guest> getAllGuests() {
        return repository.findAll();
    }

    @Override
    public Guest updateGuest(Long id, GuestDTO dto) {
        Guest guest = getGuest(id);
        guest.setName(dto.getName());
        guest.setEmail(dto.getEmail());
        guest.setPhone(dto.getPhone());
        guest.setGender(dto.getGender());
        guest.setAddress(dto.getAddress());
        return repository.save(guest);
    }

    @Override
    public void deleteGuest(Long id) {
        if (!repository.existsById(id)) {
            throw new GuestNotFoundException("Guest not found with ID: " + id);
        }
        repository.deleteById(id);
    }
}
