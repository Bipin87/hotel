package com.hotel.guest_service.controller;

import com.hotel.guest_service.dto.GuestDTO;
import com.hotel.guest_service.entity.Guest;
import com.hotel.guest_service.service.GuestService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/guests")
@RequiredArgsConstructor
public class GuestController {

    private final GuestService guestService;

    @PostMapping
    public Guest create(@RequestBody @Valid GuestDTO dto) {
        return guestService.createGuest(dto);
    }

    @GetMapping("/{id}")
    public Guest get(@PathVariable Long id) {
        return guestService.getGuest(id);
    }

    @GetMapping
    public List<Guest> getAll() {
        return guestService.getAllGuests();
    }

    @PutMapping("/{id}")
    public Guest update(@PathVariable Long id, @RequestBody @Valid GuestDTO dto) {
        return guestService.updateGuest(id, dto);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        guestService.deleteGuest(id);
    }
}
