package com.hotel.guest_service.repository;

import com.hotel.guest_service.entity.Guest;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GuestRepository extends JpaRepository<Guest, Long> {
}
