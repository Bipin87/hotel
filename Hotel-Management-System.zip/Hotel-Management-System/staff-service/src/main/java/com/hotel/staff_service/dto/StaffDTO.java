package com.hotel.staff_service.dto;

import jakarta.validation.constraints.*;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class StaffDTO {

    @NotBlank
    private String name;

    @Email
    private String email;

    @NotBlank
    private String position;

    @Min(18)
    private int age;

    @Min(0)
    private double salary;

    private String department;
}
