package com.hotel.staff_service.service;

import com.hotel.staff_service.dto.StaffDTO;
import com.hotel.staff_service.entity.Staff;

import java.util.List;

public interface StaffService {
    Staff createStaff(StaffDTO dto);
    Staff getStaffById(Long id);
    List<Staff> getAllStaff();
    Staff updateStaff(Long id, StaffDTO dto);
    void deleteStaff(Long id);
}
