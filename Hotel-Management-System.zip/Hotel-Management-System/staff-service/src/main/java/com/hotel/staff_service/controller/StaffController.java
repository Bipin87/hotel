package com.hotel.staff_service.controller;

import com.hotel.staff_service.dto.StaffDTO;
import com.hotel.staff_service.entity.Staff;
import com.hotel.staff_service.service.StaffService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/staff")
@RequiredArgsConstructor
public class StaffController {

    private final StaffService service;

    @PostMapping
    public Staff create(@RequestBody @Valid StaffDTO dto) {
        return service.createStaff(dto);
    }

    @GetMapping("/{id}")
    public Staff get(@PathVariable Long id) {
        return service.getStaffById(id);
    }

    @GetMapping
    public List<Staff> getAll() {
        return service.getAllStaff();
    }

    @PutMapping("/{id}")
    public Staff update(@PathVariable Long id, @RequestBody @Valid StaffDTO dto) {
        return service.updateStaff(id, dto);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        service.deleteStaff(id);
    }
}
