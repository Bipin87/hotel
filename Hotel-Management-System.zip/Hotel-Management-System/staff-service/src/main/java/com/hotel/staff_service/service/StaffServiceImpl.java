package com.hotel.staff_service.service;

import com.hotel.staff_service.dto.StaffDTO;
import com.hotel.staff_service.entity.Staff;
import com.hotel.staff_service.exception.StaffNotFoundException;
import com.hotel.staff_service.repository.StaffRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class StaffServiceImpl implements StaffService {

    private final StaffRepository repository;

    @Override
    public Staff createStaff(StaffDTO dto) {
        Staff staff = Staff.builder()
                .name(dto.getName())
                .email(dto.getEmail())
                .position(dto.getPosition())
                .age(dto.getAge())
                .salary(dto.getSalary())
                .department(dto.getDepartment())
                .build();
        return repository.save(staff);
    }

    @Override
    public Staff getStaffById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new StaffNotFoundException("Staff not found with ID: " + id));
    }

    @Override
    public List<Staff> getAllStaff() {
        return repository.findAll();
    }

    @Override
    public Staff updateStaff(Long id, StaffDTO dto) {
        Staff staff = getStaffById(id);
        staff.setName(dto.getName());
        staff.setEmail(dto.getEmail());
        staff.setPosition(dto.getPosition());
        staff.setAge(dto.getAge());
        staff.setSalary(dto.getSalary());
        staff.setDepartment(dto.getDepartment());
        return repository.save(staff);
    }

    @Override
    public void deleteStaff(Long id) {
        if (!repository.existsById(id)) {
            throw new StaffNotFoundException("Staff not found with ID: " + id);
        }
        repository.deleteById(id);
    }
}
