package com.hotel.rate_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RateServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
