package com.example.billservice.controller;

import com.example.billservice.repository.BillRepository;
import com.example.billservice.service.imple.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/payment") // Base path for payment-related endpoints
public class PaymentController {

    @Autowired
    private PaymentService paymentService;

    @Autowired
    private BillRepository billRepository;

    // Called when payment is successful, with sessionId from the payment gateway
    @GetMapping("/success")
    public ResponseEntity<String> handlePaymentSuccess(@RequestParam("sessionId") String sessionId) {
        return paymentService.handlePaymentSuccess(sessionId);
    }

    // Called when payment fails or is canceled
    @GetMapping("/failed")
    public String paymentCancel() {
        return "Your payment was not successful. Please try again later.";
    }
}
