package com.hotel.roomService.service.impl;

import com.hotel.roomService.dto.InventoryItemShortDTO;
import com.hotel.roomService.dto.RoomRequestDto;
import com.hotel.roomService.dto.RoomResponseDto;
import com.hotel.roomService.exception.RoomAlreadyExistsException;
import com.hotel.roomService.exception.RoomNotFoundException;
import com.hotel.roomService.model.InventoryItem;
import com.hotel.roomService.model.Room;
import com.hotel.roomService.exception.ResourceNotFoundException;
import com.hotel.roomService.repository.InventoryRepository;
import com.hotel.roomService.repository.RoomRepository;
import com.hotel.roomService.service.RoomService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class RoomServiceImpl implements RoomService {

    @Autowired
    private RoomRepository roomRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private InventoryRepository inventoryRepository;

    // Create a new room
    @Override
    public RoomResponseDto createRoom(RoomRequestDto roomRequestDto) {
        // Check if room number already exists in DB
        if (roomRepository.findByRoomNumber(roomRequestDto.getRoomNumber()).isPresent()) {
            throw new RoomAlreadyExistsException("Room number " + roomRequestDto.getRoomNumber() + " already exists.");
        }

        // Convert DTO to entity and save room
        Room room = modelMapper.map(roomRequestDto, Room.class);
        room = roomRepository.save(room);
        // Convert saved room entity back to DTO and return
        return modelMapper.map(room, RoomResponseDto.class);
    }

    // Get a specific room by its ID
    @Override
    public RoomResponseDto getRoomById(Long roomId) {
        // Find room by ID or throw exception
        Room room = roomRepository.findById(roomId)
                .orElseThrow(() -> new ResourceNotFoundException("Room not found with id: " + roomId));

        // Map room to response DTO
        RoomResponseDto dto = modelMapper.map(room, RoomResponseDto.class);

        // Map associated inventory items
        List<InventoryItemShortDTO> inventories = room.getRoomInventories().stream()
                .map(item -> modelMapper.map(item, InventoryItemShortDTO.class))
                .collect(Collectors.toList());

        dto.setRoomInventories(inventories);
        return dto;
    }

    // Get all rooms with their inventories
    @Override
    public List<RoomResponseDto> getAllRooms() {
        return roomRepository.findAll()
                .stream()
                .map(room -> {
                    // Map room to response DTO
                    RoomResponseDto roomResponseDto = modelMapper.map(room, RoomResponseDto.class);
                    // Map associated inventories
                    List<InventoryItemShortDTO> inventories = room.getRoomInventories().stream()
                            .map(item -> modelMapper.map(item, InventoryItemShortDTO.class))
                            .collect(Collectors.toList());
                    roomResponseDto.setRoomInventories(inventories);
                    return roomResponseDto;
                })
                .collect(Collectors.toList());
    }

    @Override
    public RoomResponseDto findAvailableRoomByType(String roomType) {
        List<Room> rooms = roomRepository.findAvailableRoomByType(roomType);

        // If no available rooms found, throw exception
        if (rooms.isEmpty()) {
            throw new RoomNotFoundException("Room not found of type: " + roomType);
        }

        Room room = rooms.get(0); // Get the first available room
        RoomResponseDto dto = modelMapper.map(room, RoomResponseDto.class);

        // Set room type manually for accuracy
        dto.setRoomType(room.getRoomType());
        return dto;
    }

    // Find available room by room type
    @Override
    public RoomResponseDto findRoomByType(String roomType) {
        List<Room> rooms = roomRepository.findAvailableRoomByType(roomType);

        // If no available rooms found, throw exception
        if (rooms.isEmpty()) {
            return null;
        }

        Room room = rooms.get(0); // Get the first available room
        RoomResponseDto dto = modelMapper.map(room, RoomResponseDto.class);

        // Set room type manually for accuracy
        dto.setRoomType(room.getRoomType());
        return dto;
    }

    // Delete room by ID
    public void deleteRoom(Long roomId) {
        Room room = roomRepository.findById(roomId)
                .orElseThrow(() -> new ResourceNotFoundException("Room not found with ID: " + roomId));
        roomRepository.delete(room);
    }

    // Update availability status of a room
    @Override
    public void updateRoomAvailability(Long roomId, boolean isAvailable) {
        System.out.println("Update Room");

        Room room = roomRepository.findById(roomId)
                .orElseThrow(() -> new ResourceNotFoundException("Room not found"));

        room.setAvailable(isAvailable); // Set new availability
        roomRepository.save(room); // Save changes
    }

    // Update room details
    @Override
    public RoomResponseDto updateRoom(Long roomId, RoomRequestDto roomRequestDto) {
        Room room = roomRepository.findById(roomId)
                .orElseThrow(() -> new ResourceNotFoundException("Room not found with id: " + roomId));

        // Update fields from DTO
        modelMapper.map(roomRequestDto, room);
        room = roomRepository.save(room);

        return modelMapper.map(room, RoomResponseDto.class);
    }

    // Add inventory item to a room
    @Override
    public void addInventoryToRoom(Long roomId, InventoryItem itemData) {
        Room room = roomRepository.findById(roomId)
                .orElseThrow(() -> new ResourceNotFoundException("Room not found"));

        itemData.setRoom(room); // Associate item with the room
        inventoryRepository.save(itemData); // Save inventory item
    }
}
