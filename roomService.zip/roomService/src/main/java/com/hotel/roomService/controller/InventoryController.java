package com.hotel.roomService.controller;

import com.hotel.roomService.dto.InventoryRequestDTO;
import com.hotel.roomService.dto.InventoryResponseDTO;
import com.hotel.roomService.model.InventoryItem;
import com.hotel.roomService.service.InventoryService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/inventory") // Base path for inventory APIs
public class InventoryController {

    private final InventoryService inventoryService;

    // Constructor injection for InventoryService
    public InventoryController(InventoryService inventoryService) {
        this.inventoryService = inventoryService;
    }

    // Endpoint to create a new inventory item
    @PostMapping
    public InventoryItem createItem(@RequestBody InventoryRequestDTO dto) {
        return inventoryService.createItem(dto);
    }

    // Endpoint to get a list of all inventory items
    @GetMapping
    public List<InventoryResponseDTO> getAllItems() {
        return inventoryService.getAllItems();
    }

    // Endpoint to get a specific inventory item by its ID
    @GetMapping("/{id}")
    public InventoryResponseDTO getItem(@PathVariable Long id) {
        return inventoryService.getItemById(id);
    }

    // Endpoint to update an existing inventory item by ID
    @PutMapping("/{id}")
    public InventoryItem updateItem(@PathVariable Long id, @RequestBody InventoryRequestDTO dto) {
        return inventoryService.updateItem(id, dto);
    }
}
