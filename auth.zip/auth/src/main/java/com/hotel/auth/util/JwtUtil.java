package com.hotel.auth.util;

import com.hotel.auth.model.User;
import com.hotel.auth.repository.UserRepository;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.Optional;

@Component
public class JwtUtil {

    @Autowired
    private UserRepository userRepository;

    // Secret key used for signing the JWT
    private String secret = "pG5+XlP2Fs1dzA5mV3QhKa8Lw7TqY35785899tJcRfNpMvBdU6Zoghdfhg76576fjh7657865hjgrhjXgK9HrWyEjC2Vu0IbOuyryuryu4387ergfhueruyr##$$DFDFERR^$dvhjefjhfheyur78347843jhhejjhf";

    // Token expiration time: 1 day in milliseconds
    private long expiration = 86400000;

    public String generateToken(String username) {
        Optional<User> userOptional = userRepository.findByUsername(username);

        // Throw exception if user not found
        if (!userOptional.isPresent()) {
            throw new RuntimeException("Invalid username and password");
        }

        User user = userOptional.get();
        String role = user.getRole();

        // Build and return JWT token
        return Jwts.builder()
                .setSubject(username)
                .claim("role", role) // Add user role as a custom claim
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + expiration))
                .signWith(SignatureAlgorithm.HS512, secret.getBytes()) // Sign the token using secret
                .compact();
    }
}
